# KosRent 1.0.1 — start here

Prepared for Ved Technologies. Contact: rathodar110@gmail.com.
Website: https://kosrent.vedtechnologies.co.in

The developer account is complete according to the owner. The KosRent app has not yet been created in Play Console, and this release is not published.

## Your next action

1. Open https://play.google.com/console using your existing developer account. Click **Create app**. Enter **KosRent**, select **English**, **App**, and **Free**, and complete the applicable declarations truthfully. Select **House & Home** and initial **India** availability in the appropriate setup fields.
2. Open **Testing → Internal testing → Create new release** (or the current Console equivalent). Enrol in Play App Signing and upload **kosrent-1.0.1.aab**. The APK is for direct phone testing, not the Play upload. This is version 1.0.1, version code 2.
3. Open **App integrity → App signing → App signing key certificate**. Copy its **SHA-256 fingerprint**, which is public information. Send this fingerprint back so the website can trust the Play-installed app and support the verified view without the browser toolbar on the KosRent domain. Do not send the private key, passwords or Google authorization codes. Google sign-in itself still uses a secure browser screen.
4. Paste the prepared store text from **play-store/listing.md**, upload **android/store_icon.png** and **play-store/feature-graphic.png**, and add genuine screenshots from the tested Android app. Screenshots are not included because no physical Android installation was available here.
5. Use **play-store/app-access.md**, **play-store/data-safety.md** and **play-store/declarations.md** to complete the content forms. Confirm actual reviewer login access and production log/backup handling before submission. These files identify the facts still needing the operator's review; they do not fabricate Google reviewer credentials, consent or a content rating.
6. Test the Play-installed build. Complete the testing requirement shown by your account (commonly 12 opted-in testers continuously for 14 days for new personal accounts) and any production-access application, then send the release for Google's review.

## Files and checks

- **kosrent-1.0.1.aab**: signed bundle for Google Play upload.
- **kosrent-1.0.1.apk**: signed APK for direct Android 7+ testing.
- **android/upload-certificate.pem**: public upload/direct-APK certificate, not the separate Play app-signing certificate.
- **readiness.json** and **checksums.sha256**: validation results and SHA-256 file hashes.
- **play-store/**: store text, declarations, reviewer access and full instructions.

The frontend build, 11 API/security tests and mobile Chromium checks passed. The Android build, lint (0 errors, 13 warnings), APK/AAB signatures and bundle structure passed. The pushed website commit is verified live with Ved Technologies, the contact email, no public business address, guest address/phone redaction and direct-APK association. Physical Android login, Play delivery, reviewer access, tester participation and Google's review remain external steps.

The private upload keystore/password are intentionally excluded from this public pack. Existing private material is outside Git in the managed workspace's release-private directory; keep a secure owner backup before discarding that environment. Use the same signing identity for updates or follow Google's supported upload-key reset process. Do not post private signing material publicly.

The service remains free. No payment feature is enabled. The business address is omitted from the website as requested; Google controls the separate legal/profile fields required inside Console.
